{
	"PlayerData": [
		{
			"ID": 1,
			"Forename": "Evelio",
			"Surname": "Perez",
			"ImageURL": "<insert imageurl>"
		},
		{
			"ID": 2,
			"Forename": "Gerson",
			"Surname": "Us",
			"ImageURL": "<insert imageurl>"
		}
	],
	"ClubData": [
		{
			"ID": 1,
			"Name": "Liverpool",
			"ShortName": "LVP",
			"ImageURL": "<insert imageurl>"
		}
	],
	"LeagueData": [
		{
			"ID": 28,
			"Name": "Champions",
			"ImageURL": "<insert imageurl>"
		}
	],
	"CupData": [
		{
			"ID": 2,
			"Name": "Atras",
			"ImageURL": "<insert imageurl>"
		}
	],
	"StadiumData": [
		{
			"ID": 1,
			"Name": "Stadium Anfield"
		}
	]
}
